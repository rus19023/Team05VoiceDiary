package com.voicediary;

class RecordLoader {

}
