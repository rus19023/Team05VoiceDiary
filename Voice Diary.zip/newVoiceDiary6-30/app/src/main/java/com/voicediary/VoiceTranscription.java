package com.voicediary;

import android.media.MediaPlayer;

public interface VoiceTranscription {
    void handleResult(String transcription);
}
