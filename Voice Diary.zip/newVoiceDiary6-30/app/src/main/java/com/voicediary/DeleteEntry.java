package com.voicediary;

import android.content.Intent;
import android.net.Uri;

class DeleteEntry implements Runnable {
    private String mimeType;
    private Uri initialUri;

    public void run() {

    }
    private void deleteFile(Uri initialUri) {

    }
}
